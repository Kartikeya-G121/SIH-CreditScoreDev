"""
STRATIFIED ENSEMBLE EXPLAINABILITY PIPELINE
Implements 5-fold stratified dataset splitting with ensemble XGBoost models
and multi-explainer aggregation (SHAP + LIME + XGBoost Explainer)
"""

import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import shap
from lime import lime_tabular
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

print("="*100)
print("STRATIFIED ENSEMBLE EXPLAINABILITY PIPELINE")
print("5 Datasets × 5 Models × 3 Explainers = 15 Total Explanations")
print("="*100)

# ============================================================================
# 1. LOAD AND PREPARE DATA
# ============================================================================
print("\n[1/7] Loading full dataset...")
df = pd.read_csv('c:/sriyansh/SIH/corrected_repayment_dataset.csv')

# Feature Engineering
df['dependency_ratio'] = df['family_size'] / (df['dependents_count'] + 1e-5)

# Feature Exclusions
cols_to_drop = [
    'beneficiary_id', 'partner_id', 'loan_id', 'repayment_id',
    'gender', 'age', 'category', 'education_level', 'marital_status',
    'state', 'district', 'annual_family_income', 'default_status',
    'bank_account_status', 'bank_name', 'account_type', 'loan_scheme',
    'interest_rate', 'guarantor_present', 'loan_purpose', 'business_age',
    'sector', 'last_payment_date', 'income_source', 'land_owned_acres',
    'collateral_required', 'loan_start_date', 'loan_end_date', 'Unnamed: 0'
]

df_model = df.drop(columns=[c for c in cols_to_drop if c in df.columns])
target = 'risk_score'

print(f"Total dataset size: {df_model.shape[0]} samples")
print(f"Features: {df_model.shape[1] - 1}")

# ============================================================================
# 2. STRATIFIED DATASET SPLITTING (5 BALANCED SUBSETS)
# ============================================================================
print("\n[2/7] Creating 5 stratified subsets with balanced risk distribution...")

# Categorize risk levels
df_model['risk_category'] = pd.cut(
    df_model[target], 
    bins=[0, 40, 60, 100], 
    labels=['Low', 'Medium', 'High'],
    include_lowest=True
)

# Count samples per category
risk_counts = df_model['risk_category'].value_counts()
print(f"\nOriginal dataset distribution:")
print(f"  Low Risk (0-40):     {risk_counts.get('Low', 0)} samples")
print(f"  Medium Risk (40-60): {risk_counts.get('Medium', 0)} samples")
print(f"  High Risk (60+):     {risk_counts.get('High', 0)} samples")

# Stratified split into 5 subsets
n_splits = 5
stratified_subsets = []

# Separate by risk category
low_risk_df = df_model[df_model['risk_category'] == 'Low'].copy()
medium_risk_df = df_model[df_model['risk_category'] == 'Medium'].copy()
high_risk_df = df_model[df_model['risk_category'] == 'High'].copy()

# Shuffle each category
low_risk_df = low_risk_df.sample(frac=1, random_state=42).reset_index(drop=True)
medium_risk_df = medium_risk_df.sample(frac=1, random_state=42).reset_index(drop=True)
high_risk_df = high_risk_df.sample(frac=1, random_state=42).reset_index(drop=True)

# Split each category into 5 parts
low_splits = np.array_split(low_risk_df, n_splits)
medium_splits = np.array_split(medium_risk_df, n_splits)
high_splits = np.array_split(high_risk_df, n_splits)

# Combine splits to create balanced subsets
for i in range(n_splits):
    subset = pd.concat([low_splits[i], medium_splits[i], high_splits[i]], ignore_index=True)
    subset = subset.sample(frac=1, random_state=42).reset_index(drop=True)  # Shuffle
    stratified_subsets.append(subset)
    
    print(f"\nSubset {i+1}:")
    print(f"  Total samples: {len(subset)}")
    print(f"  Low Risk:      {len(low_splits[i])} ({len(low_splits[i])/len(subset)*100:.1f}%)")
    print(f"  Medium Risk:   {len(medium_splits[i])} ({len(medium_splits[i])/len(subset)*100:.1f}%)")
    print(f"  High Risk:     {len(high_splits[i])} ({len(high_splits[i])/len(subset)*100:.1f}%)")

# ============================================================================
# 3. TRAIN/TEST SPLIT FOR EACH SUBSET (NO LEAKAGE)
# ============================================================================
print("\n[3/7] Creating train/test splits for each subset...")

dataset_splits = []

for i, subset in enumerate(stratified_subsets):
    # Remove risk_category column before modeling
    subset_clean = subset.drop(columns=['risk_category'])
    
    X_raw = subset_clean.drop(columns=[target])
    y = subset_clean[target]
    
    # 80/20 split
    X_train_raw, X_test_raw, y_train, y_test = train_test_split(
        X_raw, y, test_size=0.2, random_state=42, stratify=pd.cut(y, bins=[0, 40, 60, 100])
    )
    
    # Encode categoricals (fit only on train)
    cat_cols = X_train_raw.select_dtypes(include=['object', 'category']).columns
    label_encoders = {}
    
    X_train = X_train_raw.copy()
    X_test = X_test_raw.copy()
    
    for col in cat_cols:
        le = LabelEncoder()
        X_train[col] = le.fit_transform(X_train[col].astype(str))
        X_test[col] = le.transform(X_test[col].astype(str))
        label_encoders[col] = le
    
    dataset_splits.append({
        'subset_id': i + 1,
        'X_train': X_train,
        'X_test': X_test,
        'y_train': y_train,
        'y_test': y_test,
        'encoders': label_encoders
    })
    
    print(f"  Subset {i+1}: Train={len(X_train)}, Test={len(X_test)}")

# ============================================================================
# 4. TRAIN 5 XGBOOST MODELS (ONE PER SUBSET)
# ============================================================================
print("\n[4/7] Training 5 XGBoost models (one per stratified subset)...")

configs = [
    {'max_depth': 3, 'learning_rate': 0.1, 'n_estimators': 100, 'subsample': 0.8, 
     'colsample_bytree': 0.8, 'name': 'Model_1_Shallow'},
    {'max_depth': 6, 'learning_rate': 0.1, 'n_estimators': 100, 'subsample': 0.9, 
     'colsample_bytree': 0.9, 'name': 'Model_2_Medium'},
    {'max_depth': 9, 'learning_rate': 0.05, 'n_estimators': 150, 'subsample': 0.7, 
     'colsample_bytree': 0.7, 'name': 'Model_3_Deep'},
    {'max_depth': 6, 'learning_rate': 0.2, 'n_estimators': 80, 'subsample': 0.85, 
     'colsample_bytree': 0.85, 'name': 'Model_4_FastLR'},
    {'max_depth': 5, 'learning_rate': 0.08, 'n_estimators': 120, 'subsample': 0.75, 
     'colsample_bytree': 0.75, 'name': 'Model_5_Balanced'}
]

trained_models = []

for i, (config, data_split) in enumerate(zip(configs, dataset_splits)):
    model = xgb.XGBRegressor(
        max_depth=config['max_depth'],
        learning_rate=config['learning_rate'],
        n_estimators=config['n_estimators'],
        subsample=config['subsample'],
        colsample_bytree=config['colsample_bytree'],
        objective='reg:squarederror',
        random_state=42,
        n_jobs=-1
    )
    
    model.fit(data_split['X_train'], data_split['y_train'])
    
    # Evaluate
    y_pred_train = model.predict(data_split['X_train'])
    y_pred_test = model.predict(data_split['X_test'])
    
    train_rmse = np.sqrt(mean_squared_error(data_split['y_train'], y_pred_train))
    test_rmse = np.sqrt(mean_squared_error(data_split['y_test'], y_pred_test))
    train_r2 = r2_score(data_split['y_train'], y_pred_train)
    test_r2 = r2_score(data_split['y_test'], y_pred_test)
    
    trained_models.append({
        'model': model,
        'name': config['name'],
        'subset_id': i + 1,
        'config': config,
        'data_split': data_split,
        'metrics': {
            'train_rmse': train_rmse,
            'test_rmse': test_rmse,
            'train_r2': train_r2,
            'test_r2': test_r2
        }
    })
    
    print(f"  {config['name']} (Subset {i+1}):")
    print(f"    Train: RMSE={train_rmse:.4f}, R²={train_r2:.4f}")
    print(f"    Test:  RMSE={test_rmse:.4f}, R²={test_r2:.4f}")

# ============================================================================
# 5. GENERATE 15 EXPLANATIONS (3 TYPES × 5 MODELS)
# ============================================================================
print("\n[5/7] Generating 15 explanations (SHAP + LIME + XGBoost Explainer)...")

# Select 7 test samples from first subset for explanation
first_subset = dataset_splits[0]
X_test_sample = first_subset['X_test']
y_test_sample = first_subset['y_test']

# Select representative samples
test_with_risk = X_test_sample.copy()
test_with_risk['actual_risk'] = y_test_sample.values

high_risk = test_with_risk[test_with_risk['actual_risk'] >= 60].head(3)
medium_risk = test_with_risk[(test_with_risk['actual_risk'] >= 40) & 
                              (test_with_risk['actual_risk'] < 60)].head(2)
low_risk = test_with_risk[test_with_risk['actual_risk'] < 40].head(2)

selected_samples = pd.concat([high_risk, medium_risk, low_risk])
X_selected = selected_samples.drop(columns=['actual_risk'])
y_selected = selected_samples['actual_risk']

print(f"  Selected {len(X_selected)} samples for explanation (3 high, 2 medium, 2 low risk)")

all_explanations = {
    'shap': [],      # 5 SHAP explanations
    'lime': [],      # 5 LIME explanations
    'xgb_explainer': []  # 5 XGBoost Explainer outputs
}

explanation_metadata = []

for model_info in trained_models:
    model = model_info['model']
    model_name = model_info['name']
    data_split = model_info['data_split']
    
    print(f"\n  Processing {model_name}...")
    
    # 1. SHAP Explainer
    print(f"    → Generating SHAP explanations...")
    explainer_shap = shap.TreeExplainer(model)
    shap_values = explainer_shap.shap_values(X_selected)
    all_explanations['shap'].append(shap_values)
    
    # 2. LIME Explainer
    print(f"    → Generating LIME explanations...")
    explainer_lime = lime_tabular.LimeTabularExplainer(
        data_split['X_train'].values,
        feature_names=data_split['X_train'].columns.tolist(),
        mode='regression',
        random_state=42
    )
    
    lime_weights_for_model = []
    for idx in range(len(X_selected)):
        exp = explainer_lime.explain_instance(
            X_selected.iloc[idx].values,
            model.predict,
            num_features=10
        )
        # Convert to full feature vector
        lime_dict = dict(exp.as_list())
        lime_vector = np.zeros(len(data_split['X_train'].columns))
        for feat_name, weight in lime_dict.items():
            if feat_name in data_split['X_train'].columns:
                feat_idx = data_split['X_train'].columns.get_loc(feat_name)
                lime_vector[feat_idx] = weight
        lime_weights_for_model.append(lime_vector)
    
    all_explanations['lime'].append(np.array(lime_weights_for_model))
    
    # 3. XGBoost Feature Importance (Native Explainer)
    print(f"    → Extracting XGBoost feature importance...")
    xgb_importance = model.feature_importances_
    all_explanations['xgb_explainer'].append(xgb_importance)
    
    explanation_metadata.append({
        'model_name': model_name,
        'subset_id': model_info['subset_id'],
        'shap_shape': shap_values.shape,
        'lime_shape': np.array(lime_weights_for_model).shape,
        'xgb_shape': xgb_importance.shape
    })

print(f"\n  ✓ Generated 15 total explanations:")
print(f"    - 5 SHAP explanations")
print(f"    - 5 LIME explanations")
print(f"    - 5 XGBoost Explainer outputs")

# ============================================================================
# 6. AGGREGATE EXPLANATIONS USING K-MEANS (K=2)
# ============================================================================
print("\n[6/7] Aggregating 15 explanations using K-Means clustering (k=2)...")

# Combine all explanations into a single matrix
# For each model, we'll create a representative explanation vector
combined_explanations = []

for model_idx in range(len(trained_models)):
    # Average SHAP across all samples for this model
    shap_avg = np.mean(all_explanations['shap'][model_idx], axis=0)
    
    # Average LIME across all samples for this model
    lime_avg = np.mean(all_explanations['lime'][model_idx], axis=0)
    
    # XGBoost importance (already global)
    xgb_vec = all_explanations['xgb_explainer'][model_idx]
    
    # Combine all 3 explainers for this model
    combined_vec = np.concatenate([shap_avg, lime_avg, xgb_vec])
    combined_explanations.append(combined_vec)
    
    print(f"  Model {model_idx+1}: Combined vector shape = {combined_vec.shape}")

combined_matrix = np.array(combined_explanations)
print(f"\n  Combined explanation matrix shape: {combined_matrix.shape}")
print(f"  (5 models × {combined_matrix.shape[1]} features)")

# Scale before clustering
scaler = StandardScaler()
combined_matrix_scaled = scaler.fit_transform(combined_matrix)

# K-Means clustering
print(f"\n  Applying K-Means clustering (k=2)...")
kmeans = KMeans(n_clusters=2, random_state=42, n_init=10)
clusters = kmeans.fit_predict(combined_matrix_scaled)

cluster_0_count = np.sum(clusters == 0)
cluster_1_count = np.sum(clusters == 1)
larger_cluster = 0 if cluster_0_count > cluster_1_count else 1

print(f"  Cluster 0: {cluster_0_count} explanations")
print(f"  Cluster 1: {cluster_1_count} explanations")
print(f"  Selected larger cluster: {larger_cluster}")

# Get mean from larger cluster
larger_cluster_indices = np.where(clusters == larger_cluster)[0]
aggregated_explanation = combined_matrix[larger_cluster_indices].mean(axis=0)

# Split back into SHAP, LIME, XGB components
n_features = len(data_split['X_train'].columns)
aggregated_shap = aggregated_explanation[:n_features]
aggregated_lime = aggregated_explanation[n_features:2*n_features]
aggregated_xgb = aggregated_explanation[2*n_features:]

print(f"\n  ✓ Aggregated {len(larger_cluster_indices)} explanations from larger cluster")
print(f"    - Models in larger cluster: {[i+1 for i in larger_cluster_indices]}")

# ============================================================================
# 7. GENERATE COMPREHENSIVE REPORT
# ============================================================================
print("\n[7/7] Generating comprehensive report...")

report_lines = []
report_lines.append("="*100)
report_lines.append("STRATIFIED ENSEMBLE EXPLAINABILITY REPORT")
report_lines.append("5 Stratified Datasets × 5 XGBoost Models × 3 Explainers = 15 Total Explanations")
report_lines.append("="*100)

# Dataset Statistics
report_lines.append("\n## DATASET STRATIFICATION")
report_lines.append(f"\nTotal Dataset: {len(df_model)} samples")
report_lines.append(f"Risk Distribution:")
report_lines.append(f"  Low Risk (0-40):     {risk_counts.get('Low', 0)} samples ({risk_counts.get('Low', 0)/len(df_model)*100:.1f}%)")
report_lines.append(f"  Medium Risk (40-60): {risk_counts.get('Medium', 0)} samples ({risk_counts.get('Medium', 0)/len(df_model)*100:.1f}%)")
report_lines.append(f"  High Risk (60+):     {risk_counts.get('High', 0)} samples ({risk_counts.get('High', 0)/len(df_model)*100:.1f}%)")

report_lines.append(f"\n5 Stratified Subsets Created:")
for i, subset in enumerate(stratified_subsets):
    subset_low = len(low_splits[i])
    subset_medium = len(medium_splits[i])
    subset_high = len(high_splits[i])
    subset_total = len(subset)
    
    report_lines.append(f"\n  Subset {i+1}: {subset_total} samples")
    report_lines.append(f"    Low Risk:    {subset_low} ({subset_low/subset_total*100:.1f}%)")
    report_lines.append(f"    Medium Risk: {subset_medium} ({subset_medium/subset_total*100:.1f}%)")
    report_lines.append(f"    High Risk:   {subset_high} ({subset_high/subset_total*100:.1f}%)")

# Model Performance
report_lines.append("\n" + "="*100)
report_lines.append("## MODEL PERFORMANCE METRICS")
report_lines.append("="*100)

for model_info in trained_models:
    metrics = model_info['metrics']
    report_lines.append(f"\n{model_info['name']} (Trained on Subset {model_info['subset_id']}):")
    report_lines.append(f"  Hyperparameters:")
    report_lines.append(f"    max_depth={model_info['config']['max_depth']}, "
                       f"learning_rate={model_info['config']['learning_rate']}, "
                       f"n_estimators={model_info['config']['n_estimators']}")
    report_lines.append(f"  Training Performance:")
    report_lines.append(f"    RMSE: {metrics['train_rmse']:.4f}")
    report_lines.append(f"    R²:   {metrics['train_r2']:.4f}")
    report_lines.append(f"  Test Performance:")
    report_lines.append(f"    RMSE: {metrics['test_rmse']:.4f}")
    report_lines.append(f"    R²:   {metrics['test_r2']:.4f}")

# Explanation Analysis
report_lines.append("\n" + "="*100)
report_lines.append("## EXPLAINABILITY ANALYSIS (15 EXPLANATIONS)")
report_lines.append("="*100)

report_lines.append("\nExplanation Types Generated:")
report_lines.append("  1. SHAP (SHapley Additive exPlanations) - 5 explanations")
report_lines.append("  2. LIME (Local Interpretable Model-agnostic Explanations) - 5 explanations")
report_lines.append("  3. XGBoost Native Feature Importance - 5 explanations")
report_lines.append("  Total: 15 explanations")

for meta in explanation_metadata:
    report_lines.append(f"\n{meta['model_name']} (Subset {meta['subset_id']}):")
    report_lines.append(f"  SHAP values shape:      {meta['shap_shape']}")
    report_lines.append(f"  LIME weights shape:     {meta['lime_shape']}")
    report_lines.append(f"  XGBoost importance:     {meta['xgb_shape']}")

# K-Means Clustering
report_lines.append("\n" + "="*100)
report_lines.append("## K-MEANS CLUSTERING RESULTS")
report_lines.append("="*100)

report_lines.append(f"\nClustering Configuration: k=2, random_state=42")
report_lines.append(f"Cluster Assignments:")
report_lines.append(f"  Cluster 0: {cluster_0_count} models")
report_lines.append(f"  Cluster 1: {cluster_1_count} models")
report_lines.append(f"\nSelected Larger Cluster: {larger_cluster}")
report_lines.append(f"Models in larger cluster: {[trained_models[i]['name'] for i in larger_cluster_indices]}")

# Aggregated Explanation
report_lines.append("\n" + "="*100)
report_lines.append("## AGGREGATED EXPLANATION (Mean of Larger Cluster)")
report_lines.append("="*100)

# Top features from aggregated SHAP
feature_names = data_split['X_train'].columns
aggregated_features = list(zip(feature_names, aggregated_shap, aggregated_lime, aggregated_xgb))
aggregated_features.sort(key=lambda x: abs(x[1]), reverse=True)  # Sort by SHAP magnitude

report_lines.append("\nTop 10 Features by Aggregated SHAP Importance:")
report_lines.append(f"\n{'Feature':<30} {'SHAP':<12} {'LIME':<12} {'XGB Importance':<15}")
report_lines.append(f"{'-'*30} {'-'*12} {'-'*12} {'-'*15}")

for feat, shap_val, lime_val, xgb_val in aggregated_features[:10]:
    report_lines.append(f"{feat:<30} {shap_val:>12.4f} {lime_val:>12.4f} {xgb_val:>15.4f}")

# Sample Predictions
report_lines.append("\n" + "="*100)
report_lines.append("## SAMPLE PREDICTIONS (7 Test Samples)")
report_lines.append("="*100)

risk_categories = ['High Risk', 'High Risk', 'High Risk', 'Medium Risk', 'Medium Risk', 
                   'Low Risk', 'Low Risk']

for idx, (sample_idx, risk_cat) in enumerate(zip(X_selected.index, risk_categories)):
    report_lines.append(f"\n{'='*80}")
    report_lines.append(f"SAMPLE {idx+1}: {risk_cat}")
    report_lines.append(f"{'='*80}")
    report_lines.append(f"Actual Risk Score: {y_selected.iloc[idx]:.2f}")
    
    # Ensemble prediction
    ensemble_preds = [m['model'].predict(X_selected.iloc[[idx]])[0] for m in trained_models]
    ensemble_pred = np.mean(ensemble_preds)
    pred_std = np.std(ensemble_preds)
    
    report_lines.append(f"Ensemble Prediction: {ensemble_pred:.2f}")
    report_lines.append(f"Prediction Std Dev:  {pred_std:.2f}")
    report_lines.append(f"Prediction Error:    {abs(y_selected.iloc[idx] - ensemble_pred):.2f}")
    
    report_lines.append(f"\nIndividual Model Predictions:")
    for m_info, pred in zip(trained_models, ensemble_preds):
        report_lines.append(f"  {m_info['name']:<25} {pred:>8.2f}")
    
    # Feature contributions (using aggregated SHAP)
    report_lines.append(f"\nTop 5 Feature Contributions (Aggregated SHAP):")
    sample_shap = np.mean([exp[idx] for exp in all_explanations['shap']], axis=0)
    feature_contribs = list(zip(feature_names, sample_shap))
    feature_contribs.sort(key=lambda x: abs(x[1]), reverse=True)
    
    for feat, contrib in feature_contribs[:5]:
        direction = "↑ Increases" if contrib > 0 else "↓ Decreases"
        report_lines.append(f"  {feat:<30} {contrib:+.4f} {direction} risk")

# Summary
report_lines.append("\n" + "="*100)
report_lines.append("## SUMMARY")
report_lines.append("="*100)

avg_test_rmse = np.mean([m['metrics']['test_rmse'] for m in trained_models])
avg_test_r2 = np.mean([m['metrics']['test_r2'] for m in trained_models])

report_lines.append(f"\n✓ Successfully created 5 stratified datasets with balanced risk distribution")
report_lines.append(f"✓ Trained 5 XGBoost models with diverse hyperparameters")
report_lines.append(f"✓ Generated 15 explanations (5 SHAP + 5 LIME + 5 XGBoost Explainer)")
report_lines.append(f"✓ Applied K-Means clustering (k=2) and selected larger cluster")
report_lines.append(f"✓ Computed aggregated explanation from {len(larger_cluster_indices)} models")

report_lines.append(f"\nAverage Model Performance:")
report_lines.append(f"  Test RMSE: {avg_test_rmse:.4f}")
report_lines.append(f"  Test R²:   {avg_test_r2:.4f}")

report_lines.append("\n" + "="*100)
report_lines.append("END OF REPORT")
report_lines.append("="*100)

# Save report
report_text = '\n'.join(report_lines)
with open('c:/sriyansh/SIH/stratified_ensemble_report.txt', 'w', encoding='utf-8') as f:
    f.write(report_text)

print("\n" + report_text)
print("\n✓ Comprehensive report saved to 'stratified_ensemble_report.txt'")
print("\n" + "="*100)
print("STRATIFIED ENSEMBLE PIPELINE COMPLETE!")
print("="*100)
