import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.impute import SimpleImputer
from xgboost import XGBClassifier
import shap

# Quick test to understand SHAP structure
df = pd.read_csv('dataset.csv')

features = [
    'gas_refill_subsidy_amt_mean',
    'units_consumed_mean',
    'units_consumed_max',
    'units_consumed_min',
    'electricitybilling_amount_mean',
    'electricitybilling_amount_max',
    'electricitybilling_amount_min',
    'units_per_capita',
    'subsidy_ratio',
    'electricity_bill_per_capita',
    'average_recharge_value',
    'missing_electricity',
    'missing_gas',
    'missing_mobile'
]

X = df[features].copy()
y = df['income_category'].copy()

imputer = SimpleImputer(strategy='mean')
X_imputed = pd.DataFrame(imputer.fit_transform(X), columns=features)

le = LabelEncoder()
y_encoded = le.fit_transform(y)

X_train, X_test, y_train, y_test = train_test_split(
    X_imputed, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
)

model = XGBClassifier(random_state=42, eval_metric='mlogloss')
model.fit(X_train, y_train)

explainer = shap.TreeExplainer(model)
shap_values = explainer.shap_values(X_test[:10])  # Just first 10 samples

print("SHAP values type:", type(shap_values))
print("Is list:", isinstance(shap_values, list))
if isinstance(shap_values, list):
    print("Number of classes:", len(shap_values))
    print("Shape of each class:", [sv.shape for sv in shap_values])
    print("\nFor first sample, class 0 SHAP values:")
    print(shap_values[0][0])
    print("Shape:", shap_values[0][0].shape)
    print("Type:", type(shap_values[0][0]))
else:
    print("Shape:", shap_values.shape)
