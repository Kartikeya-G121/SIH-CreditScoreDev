import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.impute import SimpleImputer
from xgboost import XGBClassifier
import shap
from lime import lime_tabular
import warnings
warnings.filterwarnings('ignore')

print("Generating comprehensive explanations for 7 test samples...")

# Load and prepare data
df = pd.read_csv('dataset.csv')

features = [
    'gas_refill_subsidy_amt_mean',
    'units_consumed_mean',
    'units_consumed_max',
    'units_consumed_min',
    'electricitybilling_amount_mean',
    'electricitybilling_amount_max',
    'electricitybilling_amount_min',
    'units_per_capita',
    'subsidy_ratio',
    'electricity_bill_per_capita',
    'average_recharge_value',
    'missing_electricity',
    'missing_gas',
    'missing_mobile'
]

X = df[features].copy()
y = df['income_category'].copy()

# Prepare data
imputer = SimpleImputer(strategy='mean')
X_imputed = pd.DataFrame(imputer.fit_transform(X), columns=features)

le = LabelEncoder()
y_encoded = le.fit_transform(y)

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X_imputed, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
)

# Train model
model = XGBClassifier(random_state=42, eval_metric='mlogloss')
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)
y_pred_proba = model.predict_proba(X_test)

# SHAP explainer
explainer = shap.TreeExplainer(model)
shap_values = explainer.shap_values(X_test)

# LIME explainer
lime_explainer = lime_tabular.LimeTabularExplainer(
    X_train.values,
    feature_names=features,
    class_names=le.classes_,
    mode='classification'
)

# Select 7 samples: 3 Low, 2 Medium, 2 High
selected_samples = []

for class_idx, class_name in enumerate(le.classes_):
    class_indices = np.where(y_pred == class_idx)[0]
    if class_name == 'Low':
        num_samples = 3
    else:
        num_samples = 2
    
    if len(class_indices) >= num_samples:
        selected = np.random.choice(class_indices, num_samples, replace=False)
        selected_samples.extend(selected)

# Generate comprehensive explanations
with open('explaination.txt', 'w', encoding='utf-8') as f:
    f.write("="*100 + "\n")
    f.write(" "*30 + "INCOME CLASSIFICATION EXPLANATIONS\n")
    f.write(" "*20 + "SHAP + LIME + XGBoost Feature Importance Analysis\n")
    f.write("="*100 + "\n\n")
    
    f.write("This report provides comprehensive explanations for 7 test samples showing WHY each\n")
    f.write("beneficiary was classified into their particular income bracket.\n\n")
    f.write("For each sample, we provide:\n")
    f.write("  1. SHAP Explanation - Shows additive feature contributions\n")
    f.write("  2. LIME Explanation - Local interpretable model approximation\n")
    f.write("  3. XGBoost Feature Importance - Model's global feature ranking\n")
    f.write("  4. Plain English Summary - Human-readable interpretation\n\n")
    f.write("="*100 + "\n\n")
    
    for sample_num, idx in enumerate(selected_samples, 1):
        predicted_class = y_pred[idx]
        actual_class = y_test[idx]
        predicted_label = le.classes_[predicted_class]
        actual_label = le.classes_[actual_class]
        confidence = y_pred_proba[idx][predicted_class]
        
        f.write("\n" + "="*100 + "\n")
        f.write(f"SAMPLE #{sample_num} - Beneficiary Test Index #{idx}\n")
        f.write("="*100 + "\n\n")
        
        f.write(f"PREDICTION SUMMARY:\n")
        f.write(f"  Predicted Income Bracket: {predicted_label}\n")
        f.write(f"  Actual Income Bracket: {actual_label}\n")
        f.write(f"  Prediction Confidence: {confidence:.2%}\n")
        f.write(f"  Correct Prediction: {'YES' if predicted_class == actual_class else 'NO'}\n\n")
        
        # Feature values
        feature_values = X_test.iloc[idx]
        f.write(f"BENEFICIARY PROFILE:\n")
        f.write(f"  Gas Subsidy (mean): {feature_values['gas_refill_subsidy_amt_mean']:.2f}\n")
        f.write(f"  Electricity Units (mean): {feature_values['units_consumed_mean']:.2f}\n")
        f.write(f"  Electricity Units (max): {feature_values['units_consumed_max']:.2f}\n")
        f.write(f"  Units per Capita: {feature_values['units_per_capita']:.2f}\n")
        f.write(f"  Electricity Bill per Capita: {feature_values['electricity_bill_per_capita']:.2f}\n")
        f.write(f"  Average Mobile Recharge: {feature_values['average_recharge_value']:.2f}\n")
        f.write(f"  Subsidy Ratio: {feature_values['subsidy_ratio']:.2f}\n\n")
        
        # SHAP Explanation
        f.write("-"*100 + "\n")
        f.write("1. SHAP EXPLANATION (SHapley Additive exPlanations)\n")
        f.write("-"*100 + "\n\n")
        
        if len(shap_values.shape) == 3:
            instance_shap = shap_values[idx, :, predicted_class]
        else:
            instance_shap = shap_values[idx]
        
        shap_df = pd.DataFrame({
            'Feature': features,
            'Value': feature_values.values,
            'SHAP_Value': instance_shap
        })
        shap_df['Abs_SHAP'] = np.abs(shap_df['SHAP_Value'])
        shap_df = shap_df.sort_values('Abs_SHAP', ascending=False)
        
        f.write(f"SHAP values show how much each feature contributed to predicting '{predicted_label}':\n\n")
        
        positive_shap = shap_df[shap_df['SHAP_Value'] > 0].head(5)
        if len(positive_shap) > 0:
            f.write(f"Features SUPPORTING '{predicted_label}' classification:\n")
            for i, row in positive_shap.iterrows():
                f.write(f"  * {row['Feature']}: {row['Value']:.2f}\n")
                f.write(f"    SHAP contribution: +{row['SHAP_Value']:.4f}\n")
                f.write(f"    Impact: Pushes prediction TOWARD '{predicted_label}'\n\n")
        
        negative_shap = shap_df[shap_df['SHAP_Value'] < 0].head(5)
        if len(negative_shap) > 0:
            f.write(f"\nFeatures OPPOSING '{predicted_label}' classification:\n")
            for i, row in negative_shap.iterrows():
                f.write(f"  * {row['Feature']}: {row['Value']:.2f}\n")
                f.write(f"    SHAP contribution: {row['SHAP_Value']:.4f}\n")
                f.write(f"    Impact: Pushes prediction AWAY FROM '{predicted_label}'\n\n")
        
        # LIME Explanation
        f.write("\n" + "-"*100 + "\n")
        f.write("2. LIME EXPLANATION (Local Interpretable Model-agnostic Explanations)\n")
        f.write("-"*100 + "\n\n")
        
        lime_exp = lime_explainer.explain_instance(
            X_test.iloc[idx].values,
            model.predict_proba,
            num_features=10
        )
        
        f.write(f"LIME creates a simple local model to approximate the prediction for this specific case:\n\n")
        f.write(f"Top features according to LIME:\n")
        for feature_desc, weight in lime_exp.as_list()[:10]:
            direction = "SUPPORTS" if weight > 0 else "OPPOSES"
            f.write(f"  * {feature_desc}\n")
            f.write(f"    LIME weight: {weight:+.4f} ({direction} '{predicted_label}')\n\n")
        
        # XGBoost Feature Importance
        f.write("\n" + "-"*100 + "\n")
        f.write("3. XGBOOST FEATURE IMPORTANCE (Global Model Perspective)\n")
        f.write("-"*100 + "\n\n")
        
        feature_importance = model.feature_importances_
        importance_df = pd.DataFrame({
            'Feature': features,
            'Importance': feature_importance
        }).sort_values('Importance', ascending=False)
        
        f.write("XGBoost's global feature importance (how important each feature is across ALL predictions):\n\n")
        for i, row in importance_df.head(10).iterrows():
            f.write(f"  {row['Feature']}: {row['Importance']:.4f}\n")
        
        # Plain English Summary
        f.write("\n" + "-"*100 + "\n")
        f.write("4. PLAIN ENGLISH SUMMARY\n")
        f.write("-"*100 + "\n\n")
        
        top_shap_feature = shap_df.iloc[0]
        
        f.write(f"WHY WAS THIS PERSON CLASSIFIED AS '{predicted_label}' INCOME?\n\n")
        
        if predicted_label == 'High':
            f.write("This beneficiary was classified as HIGH INCOME because:\n\n")
            if top_shap_feature['SHAP_Value'] > 0:
                f.write(f"The PRIMARY REASON is their {top_shap_feature['Feature']} value of {top_shap_feature['Value']:.2f}.\n")
                f.write(f"This feature had a SHAP contribution of +{top_shap_feature['SHAP_Value']:.4f}, which strongly\n")
                f.write(f"pushed the model toward predicting High income.\n\n")
            
            f.write("High income individuals typically show:\n")
            f.write("  - Higher electricity consumption (more units used)\n")
            f.write("  - Greater per-capita utility usage\n")
            f.write("  - Lower subsidy dependency (can afford full prices)\n")
            f.write("  - Higher mobile recharge amounts\n")
            f.write("  - Larger electricity bills\n\n")
            
        elif predicted_label == 'Low':
            f.write("This beneficiary was classified as LOW INCOME because:\n\n")
            if top_shap_feature['SHAP_Value'] > 0:
                f.write(f"The PRIMARY REASON is their {top_shap_feature['Feature']} value of {top_shap_feature['Value']:.2f}.\n")
                f.write(f"This feature had a SHAP contribution of +{top_shap_feature['SHAP_Value']:.4f}, which strongly\n")
                f.write(f"pushed the model toward predicting Low income.\n\n")
            
            f.write("Low income individuals typically show:\n")
            f.write("  - Higher gas subsidy amounts (need government support)\n")
            f.write("  - Lower electricity consumption\n")
            f.write("  - Lower per-capita utility usage\n")
            f.write("  - Minimal mobile recharge activity\n")
            f.write("  - Smaller electricity bills\n\n")
            
        else:  # Medium
            f.write("This beneficiary was classified as MEDIUM INCOME because:\n\n")
            if top_shap_feature['SHAP_Value'] > 0:
                f.write(f"The PRIMARY REASON is their {top_shap_feature['Feature']} value of {top_shap_feature['Value']:.2f}.\n")
                f.write(f"This feature had a SHAP contribution of +{top_shap_feature['SHAP_Value']:.4f}, which strongly\n")
                f.write(f"pushed the model toward predicting Medium income.\n\n")
            
            f.write("Medium income individuals typically show:\n")
            f.write("  - Moderate gas subsidy amounts (around 100)\n")
            f.write("  - Moderate electricity consumption\n")
            f.write("  - Average per-capita utility usage\n")
            f.write("  - Regular mobile recharge patterns\n")
            f.write("  - Mid-range electricity bills\n\n")
        
        f.write(f"CONFIDENCE LEVEL: {confidence:.2%}\n")
        if confidence > 0.9:
            f.write("The model is VERY CONFIDENT in this prediction.\n")
        elif confidence > 0.7:
            f.write("The model is CONFIDENT in this prediction.\n")
        else:
            f.write("The model has MODERATE confidence - this case may have mixed signals.\n")
        
        f.write("\n" + "="*100 + "\n")

print("Comprehensive explanations saved to: explaination.txt")
print("Generated explanations for 7 samples: 3 Low, 2 Medium, 2 High income")
