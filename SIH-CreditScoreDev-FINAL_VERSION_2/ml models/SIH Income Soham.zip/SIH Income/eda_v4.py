import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import numpy as np

# Configuration
DATA_FILE = 'train_ready_dataset_v4.csv'
OUTPUT_DIR = 'eda_v4_diagrams'

def main():
    # 1. Load Data
    if not os.path.exists(DATA_FILE):
        print(f"Error: {DATA_FILE} not found.")
        return

    df = pd.read_csv(DATA_FILE)
    print(f"Loaded data with shape: {df.shape}")

    # 2. Create Output Directory
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
        print(f"Created directory: {OUTPUT_DIR}")

    # 3. Univariate Analysis
    print("Generating univariate plots...")
    
    # Numerical columns
    numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    # Exclude ID-like or irrelevant columns if any (beneficiary_id is likely object, but check)
    if 'beneficiary_id' in numerical_cols:
        numerical_cols.remove('beneficiary_id')

    for col in numerical_cols:
        plt.figure(figsize=(10, 6))
        sns.histplot(df[col], kde=True)
        plt.title(f'Distribution of {col}')
        plt.xlabel(col)
        plt.ylabel('Frequency')
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, f'hist_{col}.png'))
        plt.close()

    # Categorical columns
    categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
    if 'beneficiary_id' in categorical_cols:
        categorical_cols.remove('beneficiary_id')
    
    for col in categorical_cols:
        plt.figure(figsize=(10, 6))
        sns.countplot(x=col, data=df)
        plt.title(f'Count Plot of {col}')
        plt.xlabel(col)
        plt.ylabel('Count')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, f'bar_{col}.png'))
        plt.close()

    # 4. Bivariate Analysis
    print("Generating bivariate plots...")

    # Correlation Heatmap
    if len(numerical_cols) > 1:
        plt.figure(figsize=(12, 10))
        corr = df[numerical_cols].corr()
        sns.heatmap(corr, annot=True, fmt=".2f", cmap='coolwarm', square=True)
        plt.title('Correlation Heatmap')
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, 'correlation_heatmap.png'))
        plt.close()

    # Boxplots vs Target (assuming income_category is target)
    target_col = 'income_category'
    if target_col in df.columns:
        for col in numerical_cols:
            plt.figure(figsize=(10, 6))
            sns.boxplot(x=target_col, y=col, data=df)
            plt.title(f'{col} by {target_col}')
            plt.xlabel(target_col)
            plt.ylabel(col)
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, f'boxplot_{col}_vs_{target_col}.png'))
            plt.close()

    print(f"EDA completed. Diagrams saved to {OUTPUT_DIR}")

if __name__ == "__main__":
    main()
