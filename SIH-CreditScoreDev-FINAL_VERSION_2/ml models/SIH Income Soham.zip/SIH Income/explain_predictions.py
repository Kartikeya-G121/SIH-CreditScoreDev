import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.impute import SimpleImputer
from xgboost import XGBClassifier
import shap
from lime import lime_tabular
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("MODEL EXPLAINABILITY - Income Classification")
print("="*80)

# Load dataset
print("\n[1/6] Loading dataset and preparing data...")
df = pd.read_csv('dataset.csv')

# Select features
features = [
    'gas_refill_subsidy_amt_mean',
    'units_consumed_mean',
    'units_consumed_max',
    'units_consumed_min',
    'electricitybilling_amount_mean',
    'electricitybilling_amount_max',
    'electricitybilling_amount_min',
    'units_per_capita',
    'subsidy_ratio',
    'electricity_bill_per_capita',
    'average_recharge_value',
    'missing_electricity',
    'missing_gas',
    'missing_mobile'
]

target = 'income_category'

# Prepare data
X = df[features].copy()
y = df[target].copy()

# Handle missing values
imputer = SimpleImputer(strategy='mean')
X_imputed = pd.DataFrame(imputer.fit_transform(X), columns=features)

# Encode target
le = LabelEncoder()
y_encoded = le.fit_transform(y)

# Same split as training (80-20)
X_train, X_test, y_train, y_test = train_test_split(
    X_imputed, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
)

print(f"Training samples: {len(X_train)}, Test samples: {len(X_test)}")

# Train XGBoost model (best performer)
print("\n[2/6] Training XGBoost model...")
model = XGBClassifier(random_state=42, eval_metric='mlogloss')
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)
y_pred_proba = model.predict_proba(X_test)

print(f"Model accuracy on test set: {(y_pred == y_test).mean():.4f}")

# Initialize SHAP explainer
print("\n[3/6] Initializing SHAP explainer...")
explainer = shap.TreeExplainer(model)
shap_values = explainer.shap_values(X_test)

# For multi-class, shap_values is a list of arrays (one per class)
if isinstance(shap_values, list):
    # Use the SHAP values for the predicted class
    shap_values_array = np.array(shap_values)
else:
    shap_values_array = shap_values

print("SHAP values computed successfully")

# Generate explanation report
print("\n[4/6] Generating explanation report...")

# Select diverse examples from each income bracket
examples_per_class = 3
selected_indices = []

for class_idx, class_name in enumerate(le.classes_):
    # Get indices where prediction matches this class
    class_indices = np.where(y_pred == class_idx)[0]
    # Select random examples
    if len(class_indices) >= examples_per_class:
        selected = np.random.choice(class_indices, examples_per_class, replace=False)
        selected_indices.extend(selected)

# Generate detailed explanations
with open('explanations_report.txt', 'w', encoding='utf-8') as f:
    f.write("="*80 + "\n")
    f.write("INCOME CLASSIFICATION EXPLANATIONS\n")
    f.write("="*80 + "\n\n")
    f.write("This report explains WHY each beneficiary was classified into their\n")
    f.write("particular income bracket based on their utility consumption patterns.\n\n")
    
    for idx in selected_indices:
        predicted_class = y_pred[idx]
        actual_class = y_test[idx]
        predicted_label = le.classes_[predicted_class]
        actual_label = le.classes_[actual_class]
        confidence = y_pred_proba[idx][predicted_class]
        
        f.write("="*80 + "\n")
        f.write(f"Beneficiary #{idx} (Test Set Index)\n")
        f.write("="*80 + "\n")
        f.write(f"Predicted Income Bracket: {predicted_label}\n")
        f.write(f"Actual Income Bracket: {actual_label}\n")
        f.write(f"Prediction Confidence: {confidence:.2%}\n")
        f.write(f"Correct Prediction: {'[YES]' if predicted_class == actual_class else '[NO]'}\n\n")
        
        # Get SHAP values for this prediction
        # SHAP returns 3D array: (samples, features, classes)
        if len(shap_values.shape) == 3:
            # Multi-class: get SHAP values for predicted class
            instance_shap = shap_values[idx, :, predicted_class]
        else:
            # Binary classification
            instance_shap = shap_values[idx]
        
        # Get feature values
        feature_values = X_test.iloc[idx]
        
        # Create feature contribution dataframe
        contributions = pd.DataFrame({
            'Feature': features,
            'Value': feature_values.values,
            'SHAP_Contribution': instance_shap
        })
        contributions['Abs_Contribution'] = np.abs(contributions['SHAP_Contribution'])
        contributions = contributions.sort_values('Abs_Contribution', ascending=False)
        
        f.write("EXPLANATION - Why this classification?\n")
        f.write("-" * 80 + "\n\n")
        
        # Top positive contributors
        positive = contributions[contributions['SHAP_Contribution'] > 0].head(5)
        if len(positive) > 0:
            f.write(f"TOP FACTORS SUPPORTING '{predicted_label}' CLASSIFICATION:\n")
            for i, row in positive.iterrows():
                f.write(f"  * {row['Feature']}: {row['Value']:.2f}\n")
                f.write(f"    -> Contribution: +{row['SHAP_Contribution']:.4f} (pushes toward {predicted_label})\n")
            f.write("\n")
        
        # Top negative contributors
        negative = contributions[contributions['SHAP_Contribution'] < 0].head(5)
        if len(negative) > 0:
            f.write(f"TOP FACTORS AGAINST '{predicted_label}' CLASSIFICATION:\n")
            for i, row in negative.iterrows():
                f.write(f"  * {row['Feature']}: {row['Value']:.2f}\n")
                f.write(f"    -> Contribution: {row['SHAP_Contribution']:.4f} (pushes away from {predicted_label})\n")
            f.write("\n")
        
        # Human-readable summary
        f.write("SUMMARY:\n")
        top_feature = contributions.iloc[0]
        f.write(f"The primary reason for classifying this beneficiary as '{predicted_label}' income\n")
        f.write(f"is their {top_feature['Feature']} value of {top_feature['Value']:.2f}, which\n")
        f.write(f"{'strongly supports' if top_feature['SHAP_Contribution'] > 0 else 'contradicts'} ")
        f.write(f"this classification.\n\n")
        
        # Additional context
        if predicted_label == 'High':
            f.write("High income classification typically indicates:\n")
            f.write("  - Higher electricity consumption and bills\n")
            f.write("  - Greater mobile recharge amounts\n")
            f.write("  - Higher per-capita utility usage\n")
        elif predicted_label == 'Low':
            f.write("Low income classification typically indicates:\n")
            f.write("  - Lower electricity consumption and bills\n")
            f.write("  - Minimal mobile recharge activity\n")
            f.write("  - Lower per-capita utility usage\n")
        else:
            f.write("Medium income classification typically indicates:\n")
            f.write("  - Moderate electricity consumption and bills\n")
            f.write("  - Average mobile recharge patterns\n")
            f.write("  - Balanced utility usage patterns\n")
        
        f.write("\n\n")

print("Explanation report saved to: explanations_report.txt")

# Create SHAP visualizations
print("\n[5/6] Creating SHAP visualizations...")

# Summary plot - use mean absolute SHAP values across all classes
plt.figure(figsize=(12, 8))
if len(shap_values.shape) == 3:
    # For multi-class (samples, features, classes), compute mean absolute SHAP across all
    mean_abs_shap = np.mean(np.abs(shap_values), axis=(0, 2))  # Average over samples and classes
    
    # Create bar plot
    importance_df = pd.DataFrame({
        'Feature': features,
        'Importance': mean_abs_shap
    }).sort_values('Importance', ascending=True)
    
    plt.barh(importance_df['Feature'], importance_df['Importance'], color='steelblue', alpha=0.7)
    plt.xlabel('Mean |SHAP Value| (Average Impact on Prediction)', fontsize=12, fontweight='bold')
    plt.title('SHAP Feature Importance - Income Classification', fontsize=14, fontweight='bold')
    plt.grid(axis='x', alpha=0.3)
    
    # Add value labels
    for i, (feat, imp) in enumerate(zip(importance_df['Feature'], importance_df['Importance'])):
        plt.text(imp, i, f' {imp:.4f}', va='center', fontsize=9)
else:
    # For binary classification
    feature_importance = np.mean(np.abs(shap_values), axis=0)
    importance_df = pd.DataFrame({
        'Feature': features,
        'Importance': feature_importance
    }).sort_values('Importance', ascending=True)
    
    plt.barh(importance_df['Feature'], importance_df['Importance'], color='steelblue', alpha=0.7)
    plt.xlabel('Mean |SHAP Value|', fontsize=12, fontweight='bold')
    plt.title('SHAP Feature Importance', fontsize=14, fontweight='bold')
    plt.grid(axis='x', alpha=0.3)

plt.tight_layout()
plt.savefig('shap_summary.png', dpi=300, bbox_inches='tight')
plt.close()
print("SHAP summary plot saved to: shap_summary.png")

# Waterfall plots for selected examples
fig, axes = plt.subplots(3, 3, figsize=(20, 16))
fig.suptitle('SHAP Waterfall Plots - Individual Prediction Explanations', fontsize=16, fontweight='bold')

for plot_idx, test_idx in enumerate(selected_indices[:9]):  # Max 9 plots
    row = plot_idx // 3
    col = plot_idx % 3
    ax = axes[row, col]
    
    predicted_class = y_pred[test_idx]
    predicted_label = le.classes_[predicted_class]
    confidence = y_pred_proba[test_idx][predicted_class]
    
    # Get SHAP values for this instance
    if len(shap_values.shape) == 3:
        # Multi-class: get SHAP values for predicted class
        instance_shap = shap_values[test_idx, :, predicted_class]
    else:
        instance_shap = shap_values[test_idx]
    
    # Create simple bar plot as waterfall alternative
    feature_values = X_test.iloc[test_idx]
    contributions = pd.DataFrame({
        'Feature': features,
        'SHAP': instance_shap
    }).sort_values('SHAP', ascending=True)
    
    colors = ['red' if x < 0 else 'green' for x in contributions['SHAP']]
    ax.barh(contributions['Feature'], contributions['SHAP'], color=colors, alpha=0.7)
    ax.axvline(x=0, color='black', linestyle='-', linewidth=0.5)
    ax.set_xlabel('SHAP Value (impact on prediction)', fontsize=9)
    ax.set_title(f'Beneficiary #{test_idx}\nPredicted: {predicted_label} ({confidence:.1%})', 
                 fontsize=10, fontweight='bold')
    ax.grid(axis='x', alpha=0.3)
    ax.tick_params(axis='both', labelsize=8)

plt.tight_layout()
plt.savefig('shap_waterfall_samples.png', dpi=300, bbox_inches='tight')
plt.close()
print("SHAP waterfall plots saved to: shap_waterfall_samples.png")

# LIME explanations for comparison
print("\n[6/6] Generating LIME explanations...")

# Initialize LIME explainer
lime_explainer = lime_tabular.LimeTabularExplainer(
    X_train.values,
    feature_names=features,
    class_names=le.classes_,
    mode='classification'
)

# Generate LIME explanations for a few examples
with open('lime_explanations.txt', 'w', encoding='utf-8') as f:
    f.write("="*80 + "\n")
    f.write("LIME EXPLANATIONS (Alternative Method)\n")
    f.write("="*80 + "\n\n")
    
    for idx in selected_indices[:5]:  # First 5 examples
        predicted_class = y_pred[idx]
        predicted_label = le.classes_[predicted_class]
        
        # Generate LIME explanation
        lime_exp = lime_explainer.explain_instance(
            X_test.iloc[idx].values,
            model.predict_proba,
            num_features=10
        )
        
        f.write(f"\nBeneficiary #{idx} - Predicted: {predicted_label}\n")
        f.write("-" * 80 + "\n")
        f.write("LIME Feature Contributions:\n")
        for feature, weight in lime_exp.as_list():
            f.write(f"  {feature}: {weight:+.4f}\n")
        f.write("\n")

print("LIME explanations saved to: lime_explanations.txt")

print("\n" + "="*80)
print("EXPLAINABILITY GENERATION COMPLETE")
print("="*80)
print("\nGenerated files:")
print("1. explanations_report.txt - Detailed human-readable explanations")
print("2. shap_summary.png - Overall SHAP feature importance")
print("3. shap_waterfall_samples.png - Individual prediction explanations")
print("4. lime_explanations.txt - LIME-based explanations for comparison")
print("\nThese files explain WHY each person was classified into their income bracket!")
