import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix, f1_score
import warnings
warnings.filterwarnings('ignore')

# Load dataset
print("Loading dataset...")
df = pd.read_csv('dataset.csv')

# Select features
features = [
    'gas_refill_subsidy_amt_mean',
    'units_consumed_mean',
    'units_consumed_max',
    'units_consumed_min',
    'electricitybilling_amount_mean',
    'electricitybilling_amount_max',
    'electricitybilling_amount_min',
    'units_per_capita',
    'subsidy_ratio',
    'electricity_bill_per_capita',
    'average_recharge_value',
    'missing_electricity',
    'missing_gas',
    'missing_mobile'
]

# Target variable
target = 'income_category'

# Prepare data
X = df[features].copy()
y = df[target].copy()

print(f"\nDataset shape: {X.shape}")
print(f"Target distribution:\n{y.value_counts()}")

# Handle missing values with mean imputation
imputer = SimpleImputer(strategy='mean')
X_imputed = pd.DataFrame(imputer.fit_transform(X), columns=features)

# Encode target variable
le = LabelEncoder()
y_encoded = le.fit_transform(y)

print(f"\nEncoded classes: {le.classes_}")

# 80-20 train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X_imputed, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
)

print(f"\nTraining set size: {X_train.shape[0]}")
print(f"Test set size: {X_test.shape[0]}")

# Scale features for Logistic Regression
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Initialize models
models = {
    'XGBoost': XGBClassifier(random_state=42, eval_metric='mlogloss'),
    'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
    'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42)
}

# Train models and collect metrics
results = {}
feature_importances = {}

print("\n" + "="*80)
print("TRAINING MODELS AND GENERATING METRICS")
print("="*80)

for name, model in models.items():
    print(f"\n{'='*80}")
    print(f"Training {name}...")
    print(f"{'='*80}")
    
    # Use scaled data for Logistic Regression, original for tree-based models
    if name == 'Logistic Regression':
        model.fit(X_train_scaled, y_train)
        y_pred = model.predict(X_test_scaled)
    else:
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
    
    # Calculate metrics
    accuracy = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred, average='weighted')
    
    results[name] = {
        'accuracy': accuracy,
        'f1_score': f1,
        'predictions': y_pred
    }
    
    # Print metrics
    print(f"\nAccuracy: {accuracy:.4f}")
    print(f"F1 Score (weighted): {f1:.4f}")
    print(f"\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=le.classes_))
    
    # Extract feature importance
    if name == 'XGBoost':
        feature_importances[name] = model.feature_importances_
    elif name == 'Random Forest':
        feature_importances[name] = model.feature_importances_
    elif name == 'Logistic Regression':
        # Use absolute values of coefficients averaged across classes
        if len(model.coef_.shape) > 1:
            feature_importances[name] = np.abs(model.coef_).mean(axis=0)
        else:
            feature_importances[name] = np.abs(model.coef_[0])

# Save metrics report to file
print("\n" + "="*80)
print("SAVING METRICS REPORT")
print("="*80)

with open('ml_metrics_report.txt', 'w') as f:
    f.write("="*80 + "\n")
    f.write("MACHINE LEARNING METRICS REPORT\n")
    f.write("="*80 + "\n\n")
    f.write(f"Dataset: dataset.csv\n")
    f.write(f"Total samples: {len(df)}\n")
    f.write(f"Training samples: {len(X_train)} (80%)\n")
    f.write(f"Test samples: {len(X_test)} (20%)\n")
    f.write(f"Number of features: {len(features)}\n")
    f.write(f"Target variable: {target}\n")
    f.write(f"Classes: {', '.join(le.classes_)}\n\n")
    
    for name, model in models.items():
        f.write("="*80 + "\n")
        f.write(f"{name}\n")
        f.write("="*80 + "\n\n")
        
        y_pred = results[name]['predictions']
        
        f.write(f"Accuracy: {results[name]['accuracy']:.4f}\n")
        f.write(f"F1 Score (weighted): {results[name]['f1_score']:.4f}\n\n")
        
        f.write("Classification Report:\n")
        f.write(classification_report(y_test, y_pred, target_names=le.classes_))
        f.write("\n\n")
        
        f.write("Confusion Matrix:\n")
        cm = confusion_matrix(y_test, y_pred)
        f.write(str(cm))
        f.write("\n\n")

print("Metrics report saved to: ml_metrics_report.txt")

# Create feature importance visualization
print("\n" + "="*80)
print("CREATING FEATURE IMPORTANCE VISUALIZATION")
print("="*80)

fig, axes = plt.subplots(1, 3, figsize=(20, 6))
fig.suptitle('Feature Importance Comparison Across Models', fontsize=16, fontweight='bold')

for idx, (name, importances) in enumerate(feature_importances.items()):
    # Create DataFrame for plotting
    importance_df = pd.DataFrame({
        'Feature': features,
        'Importance': importances
    }).sort_values('Importance', ascending=True)
    
    # Plot
    ax = axes[idx]
    bars = ax.barh(importance_df['Feature'], importance_df['Importance'], color=plt.cm.viridis(idx/3))
    ax.set_xlabel('Importance', fontsize=12, fontweight='bold')
    ax.set_title(f'{name}\nAccuracy: {results[name]["accuracy"]:.4f}', fontsize=13, fontweight='bold')
    ax.grid(axis='x', alpha=0.3)
    
    # Add value labels on bars
    for bar in bars:
        width = bar.get_width()
        ax.text(width, bar.get_y() + bar.get_height()/2, 
                f'{width:.4f}', ha='left', va='center', fontsize=9)

plt.tight_layout()
plt.savefig('feature_importance_comparison.png', dpi=300, bbox_inches='tight')
print("Feature importance visualization saved to: feature_importance_comparison.png")

# Summary
print("\n" + "="*80)
print("SUMMARY")
print("="*80)
print("\nModel Performance Comparison:")
for name in models.keys():
    print(f"{name:25s} - Accuracy: {results[name]['accuracy']:.4f}, F1 Score: {results[name]['f1_score']:.4f}")

print("\n" + "="*80)
print("COMPLETED SUCCESSFULLY")
print("="*80)
print("\nGenerated files:")
print("1. ml_metrics_report.txt - Detailed metrics for all models")
print("2. feature_importance_comparison.png - Feature importance visualization")
