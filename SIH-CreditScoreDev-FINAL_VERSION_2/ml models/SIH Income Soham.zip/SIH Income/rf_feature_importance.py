import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.impute import SimpleImputer
import os

# Configuration
DATA_FILE = 'train_ready_dataset_v4.csv'
OUTPUT_DIR = 'eda_v4_diagrams'
OUTPUT_FILE = os.path.join(OUTPUT_DIR, 'rf_feature_importance.png')
TARGET_COL = 'income_category'

def main():
    # 1. Load Data
    if not os.path.exists(DATA_FILE):
        print(f"Error: {DATA_FILE} not found.")
        return

    df = pd.read_csv(DATA_FILE)
    print(f"Loaded data with shape: {df.shape}")

    # 2. Preprocessing
    print("Preprocessing data...")
    
    # Drop ID column if exists
    if 'beneficiary_id' in df.columns:
        df = df.drop(columns=['beneficiary_id'])
    
    # Separate features and target
    X = df.drop(columns=[TARGET_COL])
    y = df[TARGET_COL]
    
    # Handle missing values
    # Numerical: Median
    # Categorical: Mode
    numerical_cols = X.select_dtypes(include=[np.number]).columns
    categorical_cols = X.select_dtypes(include=['object', 'category']).columns
    
    # Impute numerical
    if len(numerical_cols) > 0:
        imputer_num = SimpleImputer(strategy='median')
        X[numerical_cols] = imputer_num.fit_transform(X[numerical_cols])
        
    # Impute and Encode categorical
    if len(categorical_cols) > 0:
        imputer_cat = SimpleImputer(strategy='most_frequent')
        X[categorical_cols] = imputer_cat.fit_transform(X[categorical_cols])
        
        # Label Encoding for categorical features
        for col in categorical_cols:
            le = LabelEncoder()
            X[col] = le.fit_transform(X[col].astype(str))
            
    # Encode Target
    le_target = LabelEncoder()
    y_encoded = le_target.fit_transform(y)
    
    # 3. Train Random Forest
    print("Training Random Forest Classifier...")
    rf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
    rf.fit(X, y_encoded)
    
    # 4. Extract Feature Importance
    importances = rf.feature_importances_
    feature_names = X.columns
    
    feature_importance_df = pd.DataFrame({
        'Feature': feature_names,
        'Importance': importances
    }).sort_values(by='Importance', ascending=False)
    
    print("Top 10 Features:")
    print(feature_importance_df.head(10))
    
    # 5. Plot
    print("Generating plot...")
    plt.figure(figsize=(12, 10))
    sns.barplot(x='Importance', y='Feature', data=feature_importance_df.head(20), palette='viridis')
    plt.title('Top 20 Features by Random Forest Importance')
    plt.xlabel('Importance Score')
    plt.ylabel('Feature')
    plt.tight_layout()
    
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
        
    plt.savefig(OUTPUT_FILE)
    print(f"Feature importance plot saved to {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
